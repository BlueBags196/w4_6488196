import '../models/productcardgrid_item_model.dart';
import 'package:flutter/material.dart';
import 'package:veg_shop/core/app_export.dart';

// ignore: must_be_immutable
class ProductcardgridItemWidget extends StatelessWidget {
  ProductcardgridItemWidget(
    this.productcardgridItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ProductcardgridItemModel productcardgridItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        height: 141.v,
        width: 120.h,
        decoration: AppDecoration.fillWhiteA,
        child: Stack(
          alignment: Alignment.bottomCenter,
          children: [
            CustomImageView(
              imagePath: productcardgridItemModelObj?.image,
              height: 107.v,
              width: 120.h,
              alignment: Alignment.topCenter,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.fromLTRB(11.h, 111.v, 7.h, 1.v),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(bottom: 11.v),
                      child: Text(
                        productcardgridItemModelObj.title!,
                        style: theme.textTheme.bodyMedium,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 13.v),
                      child: Text(
                        productcardgridItemModelObj.price!,
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomImageView(
                    imagePath: productcardgridItemModelObj?.image1,
                    height: 107.v,
                    width: 120.h,
                  ),
                  SizedBox(height: 4.v),
                  Padding(
                    padding: EdgeInsets.only(left: 11.h),
                    child: Text(
                      productcardgridItemModelObj.title1!,
                      style: theme.textTheme.bodyMedium,
                    ),
                  ),
                  SizedBox(height: 1.v),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: EdgeInsets.only(right: 7.h),
                      child: Text(
                        productcardgridItemModelObj.price1!,
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
