class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Shop images
  static String imgUnnamed1 = '$imagePath/img_unnamed_1.png';

  static String imgUnnamed1105x120 = '$imagePath/img_unnamed_1_105x120.png';

  static String imgUnnamed11 = '$imagePath/img_unnamed_1_1.png';

  static String imgImage5 = '$imagePath/img_image_5.png';

  static String imgImage28 = '$imagePath/img_image_28.png';

  static String imgUnnamed1107x120 = '$imagePath/img_unnamed_1_107x120.png';

  static String imgUnnamed182x117 = '$imagePath/img_unnamed_1_82x117.png';

  static String imgUnnamed187x116 = '$imagePath/img_unnamed_1_87x116.png';

  static String imgUnnamed183x98 = '$imagePath/img_unnamed_1_83x98.png';

  static String imgUnnamed12 = '$imagePath/img_unnamed_1_2.png';

  static String imgUnnamed13 = '$imagePath/img_unnamed_1_3.png';

  static String imgImage16 = '$imagePath/img_image_16.png';

  static String imgUnnamed1111x120 = '$imagePath/img_unnamed_1_111x120.png';

  static String imgUnnamed14 = '$imagePath/img_unnamed_1_4.png';

  static String imgUnnamed181x103 = '$imagePath/img_unnamed_1_81x103.png';

  static String imgImage13 = '$imagePath/img_image_13.png';

  static String imgUnnamed15 = '$imagePath/img_unnamed_1_5.png';

  static String imgUnnamed189x103 = '$imagePath/img_unnamed_1_89x103.png';

  static String imgUnnamed16 = '$imagePath/img_unnamed_1_6.png';

  static String imgUnnamed197x111 = '$imagePath/img_unnamed_1_97x111.png';

  static String imgImage16110x120 = '$imagePath/img_image_16_110x120.png';

  static String imgUnnamed198x120 = '$imagePath/img_unnamed_1_98x120.png';

  static String imgUnnamed2 = '$imagePath/img_unnamed_2.png';

  // Shop - Tab Container images
  static String imgImage15 = '$imagePath/img_image_15.png';

  static String imgGroup2 = '$imagePath/img_group_2.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
