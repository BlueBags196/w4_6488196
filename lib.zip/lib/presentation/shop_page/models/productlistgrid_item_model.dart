import '../../../core/app_export.dart';

/// This class is used in the [productlistgrid_item_widget] screen.
class ProductlistgridItemModel {
  ProductlistgridItemModel({
    this.image,
    this.text1,
    this.text2,
    this.image1,
    this.text3,
    this.text4,
    this.id,
  }) {
    image = image ?? ImageConstant.imgUnnamed1;
    text1 = text1 ?? "Tomato";
    text2 = text2 ?? "4.99/lb";
    image1 = image1 ?? ImageConstant.imgUnnamed183x98;
    text3 = text3 ?? "Apple";
    text4 = text4 ?? "4.99/lb";
    id = id ?? "";
  }

  String? image;

  String? text1;

  String? text2;

  String? image1;

  String? text3;

  String? text4;

  String? id;
}
