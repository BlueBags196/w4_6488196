import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyLargeItimWhiteA700 => theme.textTheme.bodyLarge!.itim.copyWith(
        color: appTheme.whiteA700,
      );
  static get bodyMediumItim => theme.textTheme.bodyMedium!.itim.copyWith(
        fontSize: 15.fSize,
      );
  static get bodySmall12 => theme.textTheme.bodySmall!.copyWith(
        fontSize: 12.fSize,
      );
  static get bodySmallItimffffffff => theme.textTheme.bodySmall!.itim.copyWith(
        color: Color(0XFFFFFFFF),
        fontSize: 10.fSize,
      );
  // Headline text style
  static get headlineSmallItimffffffff =>
      theme.textTheme.headlineSmall!.itim.copyWith(
        color: Color(0XFFFFFFFF),
      );
}

extension on TextStyle {
  TextStyle get inika {
    return copyWith(
      fontFamily: 'Inika',
    );
  }

  TextStyle get itim {
    return copyWith(
      fontFamily: 'Itim',
    );
  }
}
