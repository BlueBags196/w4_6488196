// ignore_for_file: must_be_immutable

part of 'shop_tab_container_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///ShopTabContainer widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class ShopTabContainerEvent extends Equatable {}

/// Event that is dispatched when the ShopTabContainer widget is first created.
class ShopTabContainerInitialEvent extends ShopTabContainerEvent {
  @override
  List<Object?> get props => [];
}
