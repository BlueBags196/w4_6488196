import 'package:veg_shop/core/app_export.dart';

class ApiClient {}
