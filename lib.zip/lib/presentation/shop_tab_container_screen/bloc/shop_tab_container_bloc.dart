import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:veg_shop/presentation/shop_tab_container_screen/models/shop_tab_container_model.dart';
part 'shop_tab_container_event.dart';
part 'shop_tab_container_state.dart';

/// A bloc that manages the state of a ShopTabContainer according to the event that is dispatched to it.
class ShopTabContainerBloc
    extends Bloc<ShopTabContainerEvent, ShopTabContainerState> {
  ShopTabContainerBloc(ShopTabContainerState initialState)
      : super(initialState) {
    on<ShopTabContainerInitialEvent>(_onInitialize);
  }

  _onInitialize(
    ShopTabContainerInitialEvent event,
    Emitter<ShopTabContainerState> emit,
  ) async {}
}
