import '../shop_page/widgets/productcardgrid_item_widget.dart';
import '../shop_page/widgets/productlist_item_widget.dart';
import '../shop_page/widgets/productlistgrid_item_widget.dart';
import 'bloc/shop_bloc.dart';
import 'models/productcardgrid_item_model.dart';
import 'models/productlist_item_model.dart';
import 'models/productlistgrid_item_model.dart';
import 'models/shop_model.dart';
import 'package:flutter/material.dart';
import 'package:veg_shop/core/app_export.dart';
import 'package:veg_shop/widgets/custom_elevated_button.dart';

// ignore_for_file: must_be_immutable
class ShopPage extends StatefulWidget {
  const ShopPage({Key? key})
      : super(
          key: key,
        );

  @override
  ShopPageState createState() => ShopPageState();
  static Widget builder(BuildContext context) {
    return BlocProvider<ShopBloc>(
      create: (context) => ShopBloc(ShopState(
        shopModelObj: ShopModel(),
      ))
        ..add(ShopInitialEvent()),
      child: ShopPage(),
    );
  }
}

class ShopPageState extends State<ShopPage>
    with AutomaticKeepAliveClientMixin<ShopPage> {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildAllProductRow(context),
                    SizedBox(height: 33.v),
                    Padding(
                      padding: EdgeInsets.only(left: 34.h),
                      child: Text(
                        "lbl_veg_product".tr,
                        style: theme.textTheme.headlineSmall,
                      ),
                    ),
                    SizedBox(height: 3.v),
                    Divider(
                      color: appTheme.black900,
                      indent: 28.h,
                      endIndent: 63.h,
                    ),
                    SizedBox(height: 19.v),
                    _buildProductCardGrid(context),
                    SizedBox(height: 35.v),
                    Padding(
                      padding: EdgeInsets.only(left: 34.h),
                      child: Text(
                        "lbl_fruit_product".tr,
                        style: theme.textTheme.headlineSmall,
                      ),
                    ),
                    SizedBox(height: 5.v),
                    Divider(
                      color: appTheme.black900,
                      indent: 28.h,
                      endIndent: 63.h,
                    ),
                    SizedBox(height: 19.v),
                    _buildProductListGrid(context),
                    SizedBox(height: 42.v),
                    _buildThirtyOneStack(context),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAllProductRow(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        children: [
          CustomElevatedButton(
            width: 101.h,
            text: "lbl_all_product".tr,
          ),
          CustomElevatedButton(
            width: 110.h,
            text: "lbl_veg_product".tr,
            buttonStyle: CustomButtonStyles.fillYellow,
          ),
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 5.h,
              vertical: 15.v,
            ),
            decoration: AppDecoration.fillYellow,
            child: Text(
              "lbl_fruit_product".tr,
              style: theme.textTheme.bodyLarge,
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 2.h,
              vertical: 13.v,
            ),
            decoration: AppDecoration.fillYellow,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 4.v),
                Text(
                  "lbl_berry_product".tr,
                  style: theme.textTheme.bodyLarge,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildProductCardGrid(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 17.h),
        child: BlocSelector<ShopBloc, ShopState, ShopModel?>(
          selector: (state) => state.shopModelObj,
          builder: (context, shopModelObj) {
            return GridView.builder(
              shrinkWrap: true,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 142.v,
                crossAxisCount: 3,
                mainAxisSpacing: 18.h,
                crossAxisSpacing: 18.h,
              ),
              physics: NeverScrollableScrollPhysics(),
              itemCount: shopModelObj?.productcardgridItemList.length ?? 0,
              itemBuilder: (context, index) {
                ProductcardgridItemModel model =
                    shopModelObj?.productcardgridItemList[index] ??
                        ProductcardgridItemModel();
                return ProductcardgridItemWidget(
                  model,
                );
              },
            );
          },
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildProductListGrid(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 17.h),
        child: BlocSelector<ShopBloc, ShopState, ShopModel?>(
          selector: (state) => state.shopModelObj,
          builder: (context, shopModelObj) {
            return GridView.builder(
              shrinkWrap: true,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 142.v,
                crossAxisCount: 3,
                mainAxisSpacing: 18.h,
                crossAxisSpacing: 18.h,
              ),
              physics: NeverScrollableScrollPhysics(),
              itemCount: shopModelObj?.productlistgridItemList.length ?? 0,
              itemBuilder: (context, index) {
                ProductlistgridItemModel model =
                    shopModelObj?.productlistgridItemList[index] ??
                        ProductlistgridItemModel();
                return ProductlistgridItemWidget(
                  model,
                );
              },
            );
          },
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBerryProductColumn(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Padding(
        padding: EdgeInsets.only(
          left: 12.h,
          right: 22.h,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 17.h),
              child: Text(
                "lbl_berry_product".tr,
                style: theme.textTheme.headlineSmall,
              ),
            ),
            SizedBox(height: 3.v),
            Divider(
              color: appTheme.black900,
              indent: 11.h,
              endIndent: 46.h,
            ),
            SizedBox(height: 19.v),
            BlocSelector<ShopBloc, ShopState, ShopModel?>(
              selector: (state) => state.shopModelObj,
              builder: (context, shopModelObj) {
                return GridView.builder(
                  shrinkWrap: true,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    mainAxisExtent: 142.v,
                    crossAxisCount: 3,
                    mainAxisSpacing: 18.h,
                    crossAxisSpacing: 18.h,
                  ),
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: shopModelObj?.productlistItemList.length ?? 0,
                  itemBuilder: (context, index) {
                    ProductlistItemModel model =
                        shopModelObj?.productlistItemList[index] ??
                            ProductlistItemModel();
                    return ProductlistItemWidget(
                      model,
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildThirtyOneStack(BuildContext context) {
    return SizedBox(
      height: 624.v,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage13,
            height: 280.v,
            width: 430.h,
            alignment: Alignment.bottomCenter,
          ),
          _buildBerryProductColumn(context),
        ],
      ),
    );
  }
}
