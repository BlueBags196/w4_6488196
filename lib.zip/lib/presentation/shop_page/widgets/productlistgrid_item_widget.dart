import '../models/productlistgrid_item_model.dart';
import 'package:flutter/material.dart';
import 'package:veg_shop/core/app_export.dart';

// ignore: must_be_immutable
class ProductlistgridItemWidget extends StatelessWidget {
  ProductlistgridItemWidget(
    this.productlistgridItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ProductlistgridItemModel productlistgridItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        height: 141.v,
        width: 120.h,
        decoration: AppDecoration.fillWhiteA,
        child: Stack(
          alignment: Alignment.bottomCenter,
          children: [
            CustomImageView(
              imagePath: productlistgridItemModelObj?.image,
              height: 107.v,
              width: 120.h,
              alignment: Alignment.topCenter,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.fromLTRB(11.h, 111.v, 7.h, 1.v),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(bottom: 11.v),
                      child: Text(
                        productlistgridItemModelObj.text1!,
                        style: theme.textTheme.bodyMedium,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 13.v),
                      child: Text(
                        productlistgridItemModelObj.text2!,
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 7.h,
                  vertical: 1.v,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(height: 9.v),
                    CustomImageView(
                      imagePath: productlistgridItemModelObj?.image1,
                      height: 83.v,
                      width: 98.h,
                    ),
                    SizedBox(height: 18.v),
                    Padding(
                      padding: EdgeInsets.only(left: 4.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(bottom: 10.v),
                            child: Text(
                              productlistgridItemModelObj.text3!,
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 12.v),
                            child: Text(
                              productlistgridItemModelObj.text4!,
                              style: theme.textTheme.bodySmall,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
