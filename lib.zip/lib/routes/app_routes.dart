import 'package:flutter/material.dart';
import 'package:veg_shop/presentation/shop_tab_container_screen/shop_tab_container_screen.dart';
import 'package:veg_shop/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String shopPage = '/shop_page';

  static const String shopTabContainerScreen = '/shop_tab_container_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        shopTabContainerScreen: ShopTabContainerScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: ShopTabContainerScreen.builder
      };
}
