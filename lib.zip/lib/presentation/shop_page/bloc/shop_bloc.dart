import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/productcardgrid_item_model.dart';
import '../models/productlistgrid_item_model.dart';
import '../models/productlist_item_model.dart';
import 'package:veg_shop/presentation/shop_page/models/shop_model.dart';
part 'shop_event.dart';
part 'shop_state.dart';

/// A bloc that manages the state of a Shop according to the event that is dispatched to it.
class ShopBloc extends Bloc<ShopEvent, ShopState> {
  ShopBloc(ShopState initialState) : super(initialState) {
    on<ShopInitialEvent>(_onInitialize);
  }

  _onInitialize(
    ShopInitialEvent event,
    Emitter<ShopState> emit,
  ) async {
    emit(state.copyWith(
        shopModelObj: state.shopModelObj?.copyWith(
      productcardgridItemList: fillProductcardgridItemList(),
      productlistgridItemList: fillProductlistgridItemList(),
      productlistItemList: fillProductlistItemList(),
    )));
  }

  List<ProductcardgridItemModel> fillProductcardgridItemList() {
    return [
      ProductcardgridItemModel(
          image: ImageConstant.imgUnnamed1,
          title: "Tomato",
          price: "4.99/lb",
          image1: ImageConstant.imgUnnamed1,
          title1: "Tomato",
          price1: "4.99/lb"),
      ProductcardgridItemModel(image: ImageConstant.imgUnnamed1105x120),
      ProductcardgridItemModel(image: ImageConstant.imgImage5),
      ProductcardgridItemModel(image: ImageConstant.imgImage28),
      ProductcardgridItemModel(image: ImageConstant.imgUnnamed182x117),
      ProductcardgridItemModel(image: ImageConstant.imgUnnamed187x116)
    ];
  }

  List<ProductlistgridItemModel> fillProductlistgridItemList() {
    return [
      ProductlistgridItemModel(
          image: ImageConstant.imgUnnamed1,
          text1: "Tomato",
          text2: "4.99/lb",
          image1: ImageConstant.imgUnnamed183x98,
          text3: "Apple",
          text4: "4.99/lb"),
      ProductlistgridItemModel(image: ImageConstant.imgUnnamed12),
      ProductlistgridItemModel(image: ImageConstant.imgImage16),
      ProductlistgridItemModel(image: ImageConstant.imgUnnamed1111x120)
    ];
  }

  List<ProductlistItemModel> fillProductlistItemList() {
    return [
      ProductlistItemModel(
          image: ImageConstant.imgUnnamed15,
          title: "Tomato",
          price: "4.99/lb",
          image1: ImageConstant.imgUnnamed189x103,
          title1: "Blackberry",
          price1: "4.99/lb"),
      ProductlistItemModel(image: ImageConstant.imgImage16110x120)
    ];
  }
}
