import '../../../core/app_export.dart';

/// This class is used in the [productcardgrid_item_widget] screen.
class ProductcardgridItemModel {
  ProductcardgridItemModel({
    this.image,
    this.title,
    this.price,
    this.image1,
    this.title1,
    this.price1,
    this.id,
  }) {
    image = image ?? ImageConstant.imgUnnamed1;
    title = title ?? "Tomato";
    price = price ?? "4.99/lb";
    image1 = image1 ?? ImageConstant.imgUnnamed1;
    title1 = title1 ?? "Tomato";
    price1 = price1 ?? "4.99/lb";
    id = id ?? "";
  }

  String? image;

  String? title;

  String? price;

  String? image1;

  String? title1;

  String? price1;

  String? id;
}
