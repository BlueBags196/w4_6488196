// ignore_for_file: must_be_immutable

part of 'shop_tab_container_bloc.dart';

/// Represents the state of ShopTabContainer in the application.
class ShopTabContainerState extends Equatable {
  ShopTabContainerState({this.shopTabContainerModelObj});

  ShopTabContainerModel? shopTabContainerModelObj;

  @override
  List<Object?> get props => [
        shopTabContainerModelObj,
      ];
  ShopTabContainerState copyWith(
      {ShopTabContainerModel? shopTabContainerModelObj}) {
    return ShopTabContainerState(
      shopTabContainerModelObj:
          shopTabContainerModelObj ?? this.shopTabContainerModelObj,
    );
  }
}
