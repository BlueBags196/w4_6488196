import 'bloc/shop_tab_container_bloc.dart';
import 'models/shop_tab_container_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:veg_shop/core/app_export.dart';
import 'package:veg_shop/presentation/shop_page/shop_page.dart';

class ShopTabContainerScreen extends StatefulWidget {
  const ShopTabContainerScreen({Key? key})
      : super(
          key: key,
        );

  @override
  ShopTabContainerScreenState createState() => ShopTabContainerScreenState();
  static Widget builder(BuildContext context) {
    return BlocProvider<ShopTabContainerBloc>(
      create: (context) => ShopTabContainerBloc(ShopTabContainerState(
        shopTabContainerModelObj: ShopTabContainerModel(),
      ))
        ..add(ShopTabContainerInitialEvent()),
      child: ShopTabContainerScreen(),
    );
  }
}

class ShopTabContainerScreenState extends State<ShopTabContainerScreen>
    with TickerProviderStateMixin {
  late TabController tabviewController;

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ShopTabContainerBloc, ShopTabContainerState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _buildShopTab(context),
                    SizedBox(
                      height: 1847.v,
                      child: TabBarView(
                        controller: tabviewController,
                        children: [
                          ShopPage.builder(context),
                          ShopPage.builder(context),
                          ShopPage.builder(context),
                          ShopPage.builder(context),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildShopTab(BuildContext context) {
    return SizedBox(
      height: 111.v,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              height: 51.v,
              width: double.maxFinite,
              decoration: BoxDecoration(
                color: appTheme.orange100,
              ),
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              height: 49.v,
              width: double.maxFinite,
              margin: EdgeInsets.only(top: 2.v),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgImage15,
                    height: 49.v,
                    width: 430.h,
                    alignment: Alignment.center,
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 93.h,
                      margin: EdgeInsets.only(
                        top: 3.v,
                        right: 38.h,
                      ),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "lbl_veg_shop".tr,
                              style: CustomTextStyles.headlineSmallItimffffffff,
                            ),
                            TextSpan(
                              text: "lbl_by_team_veggies".tr,
                              style: CustomTextStyles.bodySmallItimffffffff,
                            ),
                          ],
                        ),
                        textAlign: TextAlign.right,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              height: 61.v,
              width: double.maxFinite,
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: EdgeInsets.only(
                        left: 2.h,
                        right: 4.h,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.only(bottom: 9.v),
                            padding: EdgeInsets.symmetric(
                              horizontal: 4.h,
                              vertical: 15.v,
                            ),
                            decoration: AppDecoration.fillAmber,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(height: 3.v),
                                Text(
                                  "lbl_veg_shop2".tr,
                                  style: CustomTextStyles.bodyMediumItim,
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 4.v),
                            padding: EdgeInsets.symmetric(
                              horizontal: 15.h,
                              vertical: 2.v,
                            ),
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: fs.Svg(
                                  ImageConstant.imgGroup2,
                                ),
                                fit: BoxFit.cover,
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(height: 4.v),
                                SizedBox(
                                  width: 26.h,
                                  child: Text(
                                    "lbl_veg_shop_logo".tr,
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                    style: CustomTextStyles.bodySmall12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: 52.v,
                    width: double.maxFinite,
                    margin: EdgeInsets.only(top: 1.v),
                    decoration: BoxDecoration(
                      color: appTheme.amber700,
                    ),
                    child: TabBar(
                      controller: tabviewController,
                      labelPadding: EdgeInsets.zero,
                      labelColor: appTheme.black900,
                      labelStyle: TextStyle(
                        fontSize: 15.fSize,
                        fontFamily: 'Itim',
                        fontWeight: FontWeight.w400,
                      ),
                      unselectedLabelColor: appTheme.black900,
                      unselectedLabelStyle: TextStyle(
                        fontSize: 15.fSize,
                        fontFamily: 'Itim',
                        fontWeight: FontWeight.w400,
                      ),
                      indicator: BoxDecoration(
                        color: appTheme.red400Ad,
                      ),
                      tabs: [
                        Tab(
                          child: Text(
                            "lbl_about_us".tr,
                          ),
                        ),
                        Tab(
                          child: Text(
                            "lbl_shop".tr,
                          ),
                        ),
                        Tab(
                          child: Text(
                            "lbl_cart".tr,
                          ),
                        ),
                        Tab(
                          child: SizedBox(
                            width: 58.h,
                            child: Text(
                              "lbl_contract_us".tr,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
